package main;

import java.util.Scanner;

public class Converter {
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		int menuSelection = 0;
		while(menuSelection != 4) {
			System.out.println("Please select an option: 1. Volume Conversion 2. Distance Conversion 3. Temperature Conversion 4.quit");
			
			menuSelection = in.nextInt();
			switch(menuSelection){
			case 1:
				volumeConvert();
				break;
			case 2:
				distanceConvert();
				break;
			case 3:
				tempConvert();
				break;
			}
			
		}

	}
	//checks for desired starting units of temperature
	private static void tempConvert() {
		System.out.println("enter starting unit 1. fahrenheit 2. celsius 3. kelvin)");
		int unit = in.nextInt();
		int unit2;
		switch(unit) {
		case 1:
			//starts with fahrenheit
			System.out.println("enter ending unit 1. celsius 2. kelvin)");
			unit2 = in.nextInt();
			double val;
			switch(unit2) {
			case 1:
				//returns celsius
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees fahrenheit = " + ((val-32)*(5/9)) + " degrees celsius");
				break;
			case 2:
				//returns kelvin
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees fahrenheit = " + ((val-32)*(5/9) + 273.15) + " degrees kelvin");
				break;
			}
			break;
		case 2:
			//starts with celsius
			System.out.println("enter ending unit 1. fahrenheit 2. kelvin)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns fahrenheit
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees celsius = " + (val/(5/9)+32) + " degrees fahrenheit");
				break;
			case 2:
				//returns kelvin
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees celsius = " + (val+273.15) + " degrees kelvin");
				break;
			}
			break;
		case 3:
			//starts with kelvin
			System.out.println("enter ending unit 1. fahrenheit 2. celsius)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns fahrenheit
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees kelvin = " + ((val-273.15)/(5/9)+32) + " degrees fahrenheit");
				break;
			case 2:
				//returns celsius
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " degrees kelvin = " + (val-273.15) + " degrees celsius");
				break;
			}
			break;
		}
		
	}
	//checks for desired starting units of distance
	private static void distanceConvert() {
		System.out.println("enter starting unit 1. miles 2. kilometers 3. feet)");
		int unit = in.nextInt();
		int unit2;
		switch(unit) {
		case 1:
			//starts with miles
			System.out.println("enter ending unit 1. kilometers 2. feet)");
			unit2 = in.nextInt();
			double val;
			switch(unit2) {
			case 1:
				//returns km
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " miles = " + val/0.62137 + " kilometers");
				break;
			case 2:
				//returns feet
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " miles = " + val*5280 + " feet");
				break;
			}
			break;
		case 2:
			//starts with km
			System.out.println("enter ending unit 1. miles 2. feet)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns miles
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " kilometers = " + val*0.62137 + " miles");
				break;
			case 2:
				//returns feet
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " kilometers = roughly " + val*3281 + " feet");
				break;
			}
			break;
		case 3:
			//starts with feet
			System.out.println("enter ending unit 1. miles 2. kilometers)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns miles
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " feet = " + val/5280 + " miles");
				break;
			case 2:
				//returns km
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " feet = roughly " + val/3281 + " kilometers");
				break;
			}
			break;
		}
	}
	//checks for desired starting and ending units of volume then converts starting value to the new unit type and prints to console
	private static void volumeConvert() {
		System.out.println("enter starting unit 1. liter 2. gallon 3. cubic feet)");
		int unit = in.nextInt();
		int unit2;
		switch(unit) {
		case 1:
			//starts with liter
			System.out.println("enter ending unit 1. gallon 2. cubic feet)");
			unit2 = in.nextInt();
			double val;
			switch(unit2) {
			case 1:
				//returns gallon
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " liter = " + (val/3.785) + " gallon");
				break;
			case 2:
				//returns cubic feet
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " liter = " + (val/28.317) + " cubic feet");
				break;
			}
			break;
		case 2:
			//starts with gallon
			System.out.println("enter ending unit 1. liter 2. cubic feet)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns liter
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " gallon = " + (val*3.785) + " liter");
				break;
			case 2:
				//returns cubic feet
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " gallon = " + (val/7.481) + " cubic feet");
				break;
			}
			break;
		case 3:
			//starts with cubic feet
			System.out.println("enter ending unit 1. liter 2. gallon)");
			unit2 = in.nextInt();
			switch(unit2) {
			case 1:
				//returns liter
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " cubic feet = " + (val*28.317) + " liter");
				break;
			case 2:
				//returns gallon
				System.out.println("Enter starting Value");
				val = in.nextDouble();
				System.out.println(val + " cubic feet = " + (val*7.481) + " gallon");
				break;
			}
			break;
		}
	}

}
